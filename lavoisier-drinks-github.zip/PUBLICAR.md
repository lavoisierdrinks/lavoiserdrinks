# Lavoisier Drinks — GitHub Pages

Este pacote contém a exportação estática dos arquivos originais do site Lavoisier Drinks, com a logo, imagens, menu, detalhes dos sabores e páginas internas.

Repositório de destino: teteusantos1580-sys/lavoiserdrinks
Endereço previsto após a ativação: https://teteusantos1580-sys.github.io/lavoiserdrinks/

## Publicar
1. Extraia este ZIP.
2. Envie os arquivos e pastas extraídos para a raiz da branch `main` do repositório. O arquivo `index.html` deve ficar na raiz. Envie também `.nojekyll`, `_next` e `images`.
3. No repositório, abra Settings > Pages.
4. Em Source, selecione Deploy from a branch.
5. Selecione `main` e `/ (root)` e clique em Save.
6. Aguarde a conclusão da publicação; a página Pages exibirá o endereço ativo.

O site foi preparado especificamente para o caminho `/lavoiserdrinks/`. Uma mudança no nome do repositório exige ajustar os caminhos e gerar uma nova exportação. Não é necessário comprar um domínio.

Instagram: https://www.instagram.com/lavoisierdrinks_/

Documentação: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
